Metacritic numerical subset and explicit ID crosswalk.

Requires Node.js 20 or newer. From this folder run:

    node scripts/refresh-metacritic-scores.mjs

The builder writes data/game-identities.json, data/metacritic-users.json, data/METACRITIC-REPORT.json and corresponding public downloads. It joins by stored product/work/source-record IDs, never display names. A secondary row with no numerical score cannot supply a score: independently reviewed PC observations supplement that source and survive rebuilds. Rejected inputs fail before files are written.

The numerical secondary subset comes from https://github.com/leinstay/steamdb/releases/tag/2026-10-05 under GPL-3.0; historical explicitly marked Wikidata structured facts are CC0. See public/score-data-LICENSE.txt. The builder code is GPL-3.0-or-later. Reviewed primary numerical observations retain their source rights; they are NOT relicensed GPL or CC0. Each retains explicit PC platform, primary URL, method, and source-age evidence. Capture/retrieval dates are not measurement dates and cached pages are not live scores. The original user screenshot is excluded; its fingerprint identifies the reviewed observation only.

Source descriptions, user-review text, screenshots, artwork files, credentials and private account data are excluded. The catalog input is limited to game ID, Steam app ID and display title for the audit report; the title is not a join key. See data/METACRITIC-SOURCES.md for provenance and current limitations.
